
<!-- General JS Scripts -->
<script src="{{asset("admin/assets/js/app.min.js")}}"></script>
<!-- Template JS File -->
<script src="{{asset("admin/assets/js/scripts.js")}}"></script>
