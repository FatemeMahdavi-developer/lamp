<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<!-- General CSS Files -->
<link rel="stylesheet" href="{{asset("admin/assets/css/app.min.css")}}">
<!-- Template CSS -->
<link rel="stylesheet" href="{{asset("admin/assets/css/style.css")}}">
<link rel="stylesheet" href="{{asset("admin/assets/css/components.css")}}">
<link rel="stylesheet" href="{{asset("admin/assets/css/tagsinput.css")}}">
<link rel="stylesheet" href="{{asset("admin/assets/boundles/pretty-checkbox/pretty-checkbox.min.css")}}">
<link rel="stylesheet" href="{{asset("admin/assets/boundles/summernote/summernote-bs4.css")}}">
<link rel="stylesheet" href="{{asset("admin/assets/boundles/select2/dist/css/select2.min.css")}}">
<!-- Custom style CSS -->
<link rel="stylesheet" href="{{asset("admin/assets/css/custom.css")}}">
<link rel='shortcut icon' type='image/x-icon' href='{{asset("admin/assets/img/favicon.ico")}}'/>
<script src="{{asset("admin/assets/js/app.min.js")}}"></script>