<p dir="rtl" style="font-size: 20px"> {{$fullname}} عزیز ِ کد یک بار مصرف شما {{$code}} می باشد </p>
