<p dir="rtl" style="font-size: 20px"> {{$fullname}} عزیز ِ کد فراموشی شما {{$code}} می باشد </p>
