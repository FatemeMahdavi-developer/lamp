<p dir="rtl" style="font-size: 20px"> {{$fullname}} عزیز ِ کد فعالسازی شما {{$code}} می باشد </p>
