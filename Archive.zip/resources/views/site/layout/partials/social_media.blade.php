
<li><a href="http://twitter.com/share?text={{$title}}&url={{$url}}" rel="nofollow" target="_blank"><img src="{{asset("site/assets/image/social/twitter.png")}}" alt="twitter"></a></li>
<li><a href="https://telegram.me/share/url?url={{$url}}" rel="nofollow" target="_blank"><img src="{{asset("site/assets/image/social/telegram.png")}}" alt="telegram"></a></li>
<li><a href="https://www.facebook.com/sharer.php?u={{$url}}" rel="nofollow" target="_blank"><img src="{{asset("site/assets/image/social/facebook.png")}}" alt="facebook"></a></li>
<li><a href="whatsapp://send?text={{$url}}" rel="nofollow" target="_blank"><img src="{{asset("site/assets/image/social/whatsapp.png")}}" alt="whatsapp"></a></li>
