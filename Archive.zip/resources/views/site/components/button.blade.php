@props(['title'=>'','type'=>'submit','class'=>'btn-primary'])
<div class="col-md-12 col-sm-12 col-btn" dir="ltr" >
    <button class="btn-custom {{$class}}" type="submit">{{$title}}</button>
</div>