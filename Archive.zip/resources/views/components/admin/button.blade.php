@props(['title'=>'','type'=>'submit','class'=>'btn-primary'])
<button class="btn mr-1 {{$class}}" type="submit">{{$title}}</button>
