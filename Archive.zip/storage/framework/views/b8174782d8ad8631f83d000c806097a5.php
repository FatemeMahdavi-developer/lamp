<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="stylesheet" href="<?php echo e(asset('site/assets/vendors/css/magnific-popup.cs')); ?>s">
<link rel="stylesheet" href="<?php echo e(asset('site/assets/vendors/css/swiper-bundle.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/assets/css/main.css')); ?>"><!-- endbuild -->
<!-- jQuery-->
<script src="<?php echo e(asset('site/assets/vendors/js/jquery.min.js')); ?>"></script>
<?php /**PATH /Users/fatememahdavi/Desktop/lamp/resources/views/site/layout/partials/head.blade.php ENDPATH**/ ?>