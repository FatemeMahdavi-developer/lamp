<!doctype html>
<html lang="fa">
<head>
    <?php echo $__env->yieldContent('seo'); ?>
    <?php echo $__env->make("site.layout.partials.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head'); ?>

</head>
<body class=" has-topbar" dir="rtl" >
    <?php echo $__env->make("site.layout.partials.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php if(!str_contains(request()->route()->getName(),'auth')): ?>
    <?php echo $__env->make("site.layout.partials.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php echo $__env->make("site.layout.partials.modal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('site.layout.partials.footer_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('footer'); ?>
<script>
    $(document).ready(function () {
        $('body').persiaNumber();

        $(".select2").select2({
            placeholder: "انتخاب کنید",
            theme: "default",
            dir: "rtl",
            language: "fa"
        })
    });
</script>
<?php if(auth()->guard()->check()): ?>
    <script>
        $(".form_change_pass").submit(function (e) {
            e.preventDefault()
            $.ajax({
                url: "<?php echo e(route("user.change_pass")); ?>",
                data: $(".form_change_pass").serialize(),
                dataType: "json",
                method: $(".form_change_pass").attr("method"),
                success: function (res) {
                    $(".form_change_pass .text-danger").remove()
                    if ($(res['errors']).length) {
                        $(res['errors']).each(function (index, element) {
                            $(".form_change_pass input").each(function (inputIndex, inputElement) {
                                var name = $(inputElement).attr("name")
                                if ($(element[name]).length) {
                                    $("[name='" + name + "']").after("<span class='text text-danger'>" + element[name] + "</span>")
                                }
                            })
                        })
                    }
                    if (res == "ok") {
                        $(".form_change_pass").prepend("<div class='alert alert-success'>تغییر رمز عبور انجام شد</div>")
                        setTimeout(function () {
                            window.location.reload()
                        }, 4000)
                    }
                },
                error: function () {
                    alert("error to sending ajax data")
                }
            })
        })
    </script>
<?php endif; ?>
</body>
</html>
<?php /**PATH /Users/fatememahdavi/Desktop/lamp/resources/views/site/layout/base.blade.php ENDPATH**/ ?>