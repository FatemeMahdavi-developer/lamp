404
<?php /**PATH /Users/fatememahdavi/Desktop/lamp/resources/views/site/error/404.blade.php ENDPATH**/ ?>