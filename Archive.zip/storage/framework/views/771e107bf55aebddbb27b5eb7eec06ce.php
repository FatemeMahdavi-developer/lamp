<title><?php echo e($seo["seo_title"] ?? app('setting')[$module."_title"]); ?></title>
<meta name="robots" content="<?php echo e($seo["seo_index_kind"]); ?>">

<?php if($seo["seo_keyword"]): ?>
<meta name="keywords" content="<?php echo e($seo["seo_keyword"]); ?>">
<?php endif; ?>
<?php if($seo["seo_description"]): ?>
<meta name="description" content="<?php echo e($seo["seo_description"]); ?>">
<?php endif; ?>
<link rel="canonical" href="<?php echo e(urldecode($seo["seo_canonical"])); ?>" />
<?php /**PATH /Users/fatememahdavi/Desktop/lamp/resources/views/site/layout/partials/seo.blade.php ENDPATH**/ ?>