<?php
return [
    
    'panel'=>[
        'welcome'=>'خوش آمدید',
        'dashbord'=>'داشبورد',
        'favorites_list'=>'لیست علاقمندی',
        'comment'=>'نظرات',
        'change_password'=>'ویرایش رمز عبور',
        'logout'=>'خروج'
    ]


];

?>