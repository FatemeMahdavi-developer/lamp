<?php
return [
    
    'panel'=>[
        'welcome' => 'Welcome',
        'dashbord' => 'Dashboard',
        'favorites_list' => 'Favorites List',
        'comment' => 'Comments',
        'change_password' => 'Change Password',
        'logout' => 'Logout'
    ]

];

?>